package com.example.pdmdiogo.data.remote

import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

class FirebaseSource {
    val auth: FirebaseAuth = FirebaseAuth.getInstance()
}