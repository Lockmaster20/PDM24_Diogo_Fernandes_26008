package com.example.pdmdiogo

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.pdmdiogo.Shop.domain.model.Product
import com.example.pdmdiogo.Shop.domain.model.ShoppingList
import com.example.pdmdiogo.Shop.domain.model.User
import com.example.pdmdiogo.presentation.screens.LoginScreen
import com.example.pdmdiogo.presentation.screens.MainScreen
import com.example.pdmdiogo.presentation.screens.RegisterScreen
import com.example.pdmdiogo.presentation.screens.SharedListsScreen
import com.example.pdmdiogo.presentation.screens.ShoppingListScreen
import com.google.firebase.Firebase
import com.google.firebase.auth.auth

@Composable
fun Shop() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "login") {
        composable("login") { LoginScreen(navController) }
        composable("register") { RegisterScreen(navController) }
        composable("main") { MainScreen(navController) }
        composable("shared_lists") { SharedListsScreen(navController) }
        composable("shopping_list/{listId}/{isOwner}", arguments = listOf(
            navArgument("listId") { type = NavType.StringType },
            navArgument("isOwner") { type = NavType.BoolType }
        )) { backStackEntry ->
            val listId = backStackEntry.arguments?.getString("listId") ?: ""
            val isOwner = backStackEntry.arguments?.getBoolean("isOwner") ?: false
            ShoppingListScreen(navController, listId, isOwner)
        }
    }
}