package com.example.pdmdiogo.Shop.domain.model

data class User (
    var id: String = "",
    val name: String = "",
    val email: String = ""
)